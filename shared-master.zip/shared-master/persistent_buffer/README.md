PREREQUISITE:
- compiler that support c++0x features
- zeromq libraries to link the executable (-l zmq)

TO COMPILE:
- just type 'make' to call the Makefile


TO RUN:
- just run persistent_buffer

NOTE:
- RECEIVER (PULL) bind on:					"tcp://*:4242"
- SENDER (PUSH) bind on:					"tcp://*:4343"




