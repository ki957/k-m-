//
//  HeaderCPlusPlus.h
//  Performance_Console
//
//  Created by Gian Luigi Romita on 11/06/14.
//  Copyright (c) 2014 Gian Luigi Romita. All rights reserved.
//
#ifndef _PERF_CPLUSPLUS_
#define _PERF_CPLUSPLUS_

class Performance_CPlusPlus
{
public:
    
    static void sortArray(unsigned int array_size);
};

#endif //_PERF_CPLUSPLUS_