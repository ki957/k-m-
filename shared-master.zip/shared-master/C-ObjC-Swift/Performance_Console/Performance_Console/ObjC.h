//
//  Header.h
//  Performance_Console
//
//  Created by Gian Luigi Romita on 11/06/14.
//  Copyright (c) 2014 Gian Luigi Romita. All rights reserved.
//
#import <Foundation/Foundation.h>

@interface Performance_ObjectiveC : NSObject 
+ (void) sortArrayObjC: (NSInteger) array_size;
@end


